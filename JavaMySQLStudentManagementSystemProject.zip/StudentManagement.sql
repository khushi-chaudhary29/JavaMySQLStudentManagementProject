create database StudentManagementSystem;
use StudentManagementSystem;
create table student(StudentID varchar(10) primary key,FirstName varchar(25),LastName varchar(25),DateOfBirth DateTime not null,Gender varchar(25)not null,Email varchar(30)unique not null,phone varchar(25)not null);
ALTER TABLE student ADD marks INT;
UPDATE student SET marks = 987;
UPDATE student SET marks = NULL;


create table course(CourseID varchar(10)primary key,CourseTitle varchar(30) not null,Credits int not null);
create table Instructor(InstructorID varchar(10)primary key,Email varchar(30)unique not null,FirstName varchar(30)not null,LastName varchar(30));
create table Enrollment(EnrollmentID varchar(10) primary key,StudentID varchar(10)not null,CourseID varchar(10)not null,InstructorID varchar(10)not null,foreign key(StudentID)references Student(StudentID),foreign key(CourseID)references course(CourseID),foreign key(InstructorID)references instructor(InstructorID));
create table Score(ScoreID varchar(10)primary key,StudentID varchar(10)not null,CourseID varchar(10)not null,foreign key(StudentID)references Student(StudentID),foreign key(CourseID)references course(CourseID),CreditObtained varchar(10)not null,DateOfExam DateTime not null);
create table feedback(FeedbackID int auto_increment primary key,StudentID varchar(10) not null,InstructrName varchar(10)not null,Feedback varchar(100)not null);
drop table feedback;
insert into student(StudentID, FirstName,LastName,DateOfBirth,Gender,Email,Phone) values('S101','Khushi','Chaudhary','2002-12-29','F','khushi@gmail.com','9876543210');
insert into student(StudentID, FirstName,LastName,DateOfBirth,Gender,Email,Phone) values('S102','Neetu','Jain','2001-11-28','F','abc@gmail.com','654217890');
insert into student(StudentID, FirstName,LastName,DateOfBirth,Gender,Email,Phone) values('S103','Riyi','Bhardwaj','2002-03-21','M','okl@gmail.com','7777644373');
insert into student(StudentID, FirstName,LastName,DateOfBirth,Gender,Email,Phone) values('S104','Vidushi','Sing','2002-09-06','F','ju@gmail.com','889098890');
insert into student(StudentID, FirstName,LastName,DateOfBirth,Gender,Email,Phone) values('S105','Aayushi','Chaudhary','2000-03-04','F','mj@gmail.com','322211443');

insert into course values('C010','Math','12'),('C012','Science','13'),('C013','History','11');

insert into instructor values('l101','suni@gmail.com','Sunil','Rawat'),('l102','juk@gmail.com','Jack','Singh'),('l103','lop@gmail.com','Lani','Jain');

insert into enrollment values('E010','S101','C010','l102');
insert into enrollment values('E011','S102','C012','l101'),('E012','S103','C013','l103');
insert into score values('SC101','S101','C010','12','2024-12-10'),('SC102','S102','C012','10','2024-12-10');
insert into Feedback(StudentID,InstructrName,Feedback) values('S101','Sunil','Session was good'),('S102','Jack','Topic was well explained');
desc Student;
select * from student;
DELETE FROM student WHERE StudentID = '111';

