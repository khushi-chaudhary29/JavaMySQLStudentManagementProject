package studentpkg;

public interface StudentDaoIntrf {
	public void createStudent(Student stu);
	public void showAllStudent();
	public void showStudentBasedOnId(String studentID);
	public void updateStudent(String studentID, String firstName);
	public void deleteStudent(String studentID);

}
